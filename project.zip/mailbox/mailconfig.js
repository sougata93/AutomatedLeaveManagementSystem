module.exports.READ_MAIL_CONFIG = {
    imap: {
      user: 'sougatamahata93@gmail.com',
      password: 'kwwwxlxlnkspjvlo',
      host: 'imap.gmail.com',
      port: 993,
      authTimeout: 10000,
      tls: true,
      tlsOptions: { rejectUnauthorized: false },
    },
  };